Install dependecies using requirements. txt
python -m pip install -r requirements.txt


Then run the following command

time python cspliceai.py        -I <input vcf file> \
                                -O <output file> \
                                -R <reference genome path> \
                                -A <splice ai annotation file provided in original package> \
                                -D 500

